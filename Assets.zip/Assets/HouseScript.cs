using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class HouseScript : MonoBehaviour
{
    public Rigidbody rb;
    // Start is called before the first frame update
    void Start()
    {
        gameObject.name = "mfao";
        Debug.Log("START!");
    }

    // Update is called once per frame
    void Update()
    {
        //
    }
}
